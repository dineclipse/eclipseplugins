*Required.* The name and version of each stemcell in the deployment.

Example:

	stemcells:
	- alias: default
	  os: ubuntu-trusty
	  version: 3147
	- alias: default2
	  name: bosh-aws-xen-hvm-ubuntu-trusty-go_agent
	  version: 3149
