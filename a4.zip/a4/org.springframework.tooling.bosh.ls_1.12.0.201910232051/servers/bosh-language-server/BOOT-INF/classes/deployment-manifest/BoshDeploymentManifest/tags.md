*Optional*. Specifies key value pairs to be sent to the CPI for VM tagging. Combined with runtime config level tags during the deploy. Available in bosh-release v258+.

Example:

	tags:
	  project: cf
