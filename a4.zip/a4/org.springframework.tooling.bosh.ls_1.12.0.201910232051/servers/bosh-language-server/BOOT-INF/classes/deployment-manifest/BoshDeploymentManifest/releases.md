*Required*. The name and version of each release in the deployment.

Example:

	releases:
	- {name: redis, version: 12}
