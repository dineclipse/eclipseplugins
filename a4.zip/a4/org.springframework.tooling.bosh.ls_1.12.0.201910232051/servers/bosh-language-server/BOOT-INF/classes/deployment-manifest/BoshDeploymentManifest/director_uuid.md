*Required*. This string must match the UUID of the currently targeted Director for the CLI to allow any operations on the deployment. Use `bosh env` to display the UUID of the currently targeted Director.

Example:

	name: my-redis
	director_uuid: cf8dc1fc-9c42-4ffc-96f1-fbad983a6ce6
