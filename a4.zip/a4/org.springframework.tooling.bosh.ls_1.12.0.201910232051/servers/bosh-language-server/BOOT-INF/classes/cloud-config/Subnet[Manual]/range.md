*Required*. Subnet IP range that includes all IPs from this subnet.
