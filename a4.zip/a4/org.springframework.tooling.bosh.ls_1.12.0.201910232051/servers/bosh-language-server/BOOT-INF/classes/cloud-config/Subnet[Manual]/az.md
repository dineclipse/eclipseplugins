AZ associated with this subnet (should only be used when using [first class AZs](https://bosh.io/docs/azs.html)). Example: `z1`. Available in v241+.
