The `name` attribute is the only required attribute for an application in a manifest file.

This is an example of a minimal manifest:

```
---
applications:
- name: nifty-gui
```