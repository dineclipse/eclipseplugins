Use the `stack` attribute to specify which stack to deploy your application to.

To see a list of available stacks, run `cf stacks` from the cf cli.

```
---
  ...
  stack: cflinuxfs2
```

The command line option that overrides this attribute is `-s`.