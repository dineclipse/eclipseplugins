*Required.* The platform the task should run on. By convention, `windows`, 
`linux`, or `darwin` are specified. This determines the pool of workers 
that the task can run against. The base deployment provides Linux workers.
