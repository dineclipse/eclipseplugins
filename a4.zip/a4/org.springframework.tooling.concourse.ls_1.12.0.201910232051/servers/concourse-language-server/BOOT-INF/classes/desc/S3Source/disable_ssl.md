*Optional.* Disable SSL for the endpoint, useful for S3
compatible providers without SSL.