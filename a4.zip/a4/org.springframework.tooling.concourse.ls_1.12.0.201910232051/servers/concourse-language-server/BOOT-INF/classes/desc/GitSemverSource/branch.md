*Required.* The branch the file lives on.
