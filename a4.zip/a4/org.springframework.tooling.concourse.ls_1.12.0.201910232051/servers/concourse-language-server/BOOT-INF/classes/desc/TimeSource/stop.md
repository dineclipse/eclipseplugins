*Optional.* Only create new time versions between `start` and `stop`
time range. The supported time formats are: `3:04 PM`, `3PM`, `3 PM`,
`15:04`, and `1504`.

e.g.

	start: 8:00 PM
	stop: 9:00 PM

**Deprecation: an offset may be appended, e.g. `+0700` or `-0400`, but you
should use `location` instead.**
