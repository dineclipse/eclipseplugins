*Optional*. If specified, only the listed artifacts will be provided to the container. If not specified, all artifacts will be provided.
