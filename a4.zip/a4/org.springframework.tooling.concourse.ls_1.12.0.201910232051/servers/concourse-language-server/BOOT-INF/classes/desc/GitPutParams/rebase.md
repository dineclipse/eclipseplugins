*Optional.* If pushing fails with non-fast-forward, continuously
attempt rebasing and pushing.
