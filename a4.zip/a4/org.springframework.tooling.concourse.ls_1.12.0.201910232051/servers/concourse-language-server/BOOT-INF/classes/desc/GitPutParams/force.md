*Optional.* When set to 'true' this will force the branch to be
pushed regardless of the upstream state.