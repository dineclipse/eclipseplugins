*Optional.* If specified as (list of pairs `name` and `value`)
it will configure git global options, setting each name with each value.

This can be useful to set options like `credential.helper` or similar.

See the [`git-config(1)` manual page](https://www.kernel.org/pub/software/scm/git/docs/git-config.html)
for more information and documentation of existing git options.