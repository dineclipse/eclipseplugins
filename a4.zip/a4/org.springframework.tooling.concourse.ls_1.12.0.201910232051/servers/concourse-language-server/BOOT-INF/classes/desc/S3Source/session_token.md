*Optional*. The AWS STS session token to use when accessing the bucket.
