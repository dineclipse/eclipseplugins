*Optional*. Default is *false*. When enabled the parallel step will fail fast by returning as soon as any
sub-step fails. This means that running steps will be interrupted and pending steps will no longer be
scheduled.

