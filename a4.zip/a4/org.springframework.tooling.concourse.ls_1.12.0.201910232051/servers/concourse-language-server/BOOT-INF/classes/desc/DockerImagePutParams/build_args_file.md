Optional.* Path to a JSON file containing Docker build
arguments.

Example file contents:

```yaml
{ "email": "me@yopmail.com", "how_many_things": 1, "do_thing": false }
```            
