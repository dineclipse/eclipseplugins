*Required*. The name of the repository, e.g. `alpine`.
