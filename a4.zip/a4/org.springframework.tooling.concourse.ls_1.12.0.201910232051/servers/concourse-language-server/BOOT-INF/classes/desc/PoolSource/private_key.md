*Optional.* Private key to use when pulling/pushing. Ensure it does not require a password.
    
Example:

	private_key: |
	  -----BEGIN RSA PRIVATE KEY-----
	  MIIEowIBAAKCAQEAtCS10/f7W7lkQaSgD/mVeaSOvSF9ql4hf/zfMwfVGgHWjj+W
	  <Lots more text>
	  DWiJL+OFeg9kawcUL6hQ8JeXPhlImG6RTUffma9+iGQyyBMCGd1l
	  -----END RSA PRIVATE KEY-----
