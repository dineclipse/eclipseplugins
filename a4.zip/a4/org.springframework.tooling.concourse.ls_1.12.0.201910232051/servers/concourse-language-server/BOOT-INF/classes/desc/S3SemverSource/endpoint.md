*Optional.* Custom endpoint for using S3 compatible provider.
