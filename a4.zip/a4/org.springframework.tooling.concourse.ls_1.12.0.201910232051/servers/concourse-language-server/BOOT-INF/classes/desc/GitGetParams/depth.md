*Optional.* If a positive integer is given, *shallow* clone the
repository using the `--depth` option. Using this flag voids your warranty.
Some things will stop working unless we have the entire history.