*Optional. Default `""`* TLS key for the notary server.
