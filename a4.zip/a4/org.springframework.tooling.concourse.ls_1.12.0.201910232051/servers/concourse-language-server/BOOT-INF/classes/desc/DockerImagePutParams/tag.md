**DEPRECATED - Use `tag_file` instead**
