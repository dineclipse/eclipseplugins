*Optional.*  Default `false`. If true, the pushed image will
be tagged as `latest` in addition to whatever other tag was specified.