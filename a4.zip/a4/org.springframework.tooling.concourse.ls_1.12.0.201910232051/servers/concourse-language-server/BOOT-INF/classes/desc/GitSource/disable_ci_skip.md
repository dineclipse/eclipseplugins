*Optional.* Allows for commits that have been labeled with `[ci skip]` or `[skip ci]`
previously to be discovered by the resource.