*Optional.* A path to a directory containing an image to `docker load` 
before running `docker build`. The directory must have `image`,
`image-id`, `repository`, and `tag` present, i.e. the tree produced by `/in`.