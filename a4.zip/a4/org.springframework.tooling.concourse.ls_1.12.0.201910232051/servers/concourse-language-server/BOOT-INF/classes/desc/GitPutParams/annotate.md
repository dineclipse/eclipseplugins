*Optional.* If specified the tag will be an
[annotated](https://git-scm.com/book/en/v2/Git-Basics-Tagging#Annotated-Tags)
tag rather than a
[lightweight](https://git-scm.com/book/en/v2/Git-Basics-Tagging#Lightweight-Tags)
tag. The value should be a path to a file containing the annotation message.