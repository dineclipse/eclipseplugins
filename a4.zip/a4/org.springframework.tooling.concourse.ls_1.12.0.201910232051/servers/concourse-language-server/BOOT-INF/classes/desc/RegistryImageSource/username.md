*Optional.* A username to use when
  authenticating to the registry. Must be specified for private repos or when
  using `put`.

