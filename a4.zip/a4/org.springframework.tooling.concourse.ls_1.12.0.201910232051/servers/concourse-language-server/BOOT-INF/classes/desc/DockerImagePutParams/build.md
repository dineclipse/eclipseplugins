*Optional.* The path of a directory containing a `Dockerfile` to build.
