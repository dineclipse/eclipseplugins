*Optional.* If specified, dictates how long to wait until retrying 
to acquire a lock or release a lock. The default is 10 seconds.
Valid values: `60s`, `90m`, `1h`.