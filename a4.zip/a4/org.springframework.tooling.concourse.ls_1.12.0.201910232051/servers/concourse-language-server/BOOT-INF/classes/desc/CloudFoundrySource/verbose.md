*Optional*. Invoke `cf` cli using `CF_TRACE=true` to print all API calls made to Cloud Foundry.

