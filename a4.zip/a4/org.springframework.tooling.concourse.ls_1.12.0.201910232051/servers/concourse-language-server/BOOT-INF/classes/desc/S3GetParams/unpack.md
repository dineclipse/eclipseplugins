*Optional*. If true and the file is an archive (tar, gzipped tar, other gzipped file, or zip), unpack the file. 
Gzipped tarballs will be both ungzipped and untarred. It is ignored when `get` is running on the initial version.
