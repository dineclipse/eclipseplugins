*Optional.* A path to a file to `docker load` and then push.
Requires `load_repository`.