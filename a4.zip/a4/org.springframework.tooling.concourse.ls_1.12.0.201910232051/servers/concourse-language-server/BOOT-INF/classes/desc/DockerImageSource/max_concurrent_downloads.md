*Optional*. Maximum concurrent downloads.

Limits the number of concurrent download threads.