*Optional*. The value should be a path to a file containing the name of the tag.
