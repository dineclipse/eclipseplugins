*Optional.* The ID of the AWS KMS master encryption key
used for the object.
