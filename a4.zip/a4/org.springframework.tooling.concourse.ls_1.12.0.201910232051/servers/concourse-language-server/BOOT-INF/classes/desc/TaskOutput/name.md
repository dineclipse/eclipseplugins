*Required.* The logical name of the output. The contents under `path` will be made available to the rest of the plan under this name.
