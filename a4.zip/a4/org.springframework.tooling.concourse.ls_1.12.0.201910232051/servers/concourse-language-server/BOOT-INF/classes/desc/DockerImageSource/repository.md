*Required.* The name of the repository, e.g.
`concourse/docker-image-resource`.