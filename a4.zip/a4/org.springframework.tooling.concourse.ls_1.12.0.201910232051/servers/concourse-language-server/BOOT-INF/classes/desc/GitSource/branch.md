The branch to track. This is *optional* if the resource is
only used in `get` steps (default value in this case is `master`).
However, it is *required* when used in a `put` step.