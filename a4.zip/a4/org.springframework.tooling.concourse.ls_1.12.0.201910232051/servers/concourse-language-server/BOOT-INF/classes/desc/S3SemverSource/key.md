*Required.* The key to use for the object in the bucket tracking
the version.