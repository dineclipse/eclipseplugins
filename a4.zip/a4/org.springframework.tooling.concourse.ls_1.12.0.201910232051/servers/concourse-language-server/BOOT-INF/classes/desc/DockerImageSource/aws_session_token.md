*Optional*. AWS session token (assumed role) to use for acquiring ECR credentials.

