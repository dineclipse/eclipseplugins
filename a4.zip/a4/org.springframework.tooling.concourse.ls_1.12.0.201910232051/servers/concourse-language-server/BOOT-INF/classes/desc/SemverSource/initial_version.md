*Optional.* The version number to use when bootstrapping, i.e. when 
there is not a version number present in the source.