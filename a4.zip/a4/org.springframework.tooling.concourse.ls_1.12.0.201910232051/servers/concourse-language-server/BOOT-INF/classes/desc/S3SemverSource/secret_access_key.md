*Required.* The AWS secret key to use when accessing
the bucket.