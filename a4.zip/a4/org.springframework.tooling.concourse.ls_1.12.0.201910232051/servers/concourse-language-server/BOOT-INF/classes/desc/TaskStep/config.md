*One of `config` or `file` attributes is required.*

Use `config` to inline the task config statically.
