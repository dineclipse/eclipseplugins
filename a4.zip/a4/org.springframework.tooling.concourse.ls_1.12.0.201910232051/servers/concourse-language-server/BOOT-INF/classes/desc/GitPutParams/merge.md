*Optional*. If pushing fails with non-fast-forward, continuously attempt to merge remote to local before pushing. Only one of `merge` or `rebase` can be provided, but not both.
