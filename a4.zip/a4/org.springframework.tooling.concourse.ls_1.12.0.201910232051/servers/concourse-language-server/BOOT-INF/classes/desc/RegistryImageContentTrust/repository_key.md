 *Required.* Target key used to sign the trusted collection.
