*Optional.* An array of CIDRs or `host:port` addresses
to whitelist for insecure access (either `http` or unverified `https`).
This option overrides any entries in `ca_certs` with the same address.