*Optional.* **DEPRECATED. Use `get` and `load` instead.** A
path to a repository to pull down, and then push to this resource.
