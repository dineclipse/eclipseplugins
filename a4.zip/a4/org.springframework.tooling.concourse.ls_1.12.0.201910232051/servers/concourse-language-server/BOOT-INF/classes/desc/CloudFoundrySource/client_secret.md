*Optional*. The client secret used to authenticate.
