*Optional*. Map of variables to pass to manifest
