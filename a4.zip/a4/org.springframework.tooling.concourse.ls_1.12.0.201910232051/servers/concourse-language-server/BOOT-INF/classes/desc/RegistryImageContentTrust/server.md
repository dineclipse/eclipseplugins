*Optional.* URL for the notary server. (equal to `DOCKER_CONTENT_TRUST_SERVER`)
