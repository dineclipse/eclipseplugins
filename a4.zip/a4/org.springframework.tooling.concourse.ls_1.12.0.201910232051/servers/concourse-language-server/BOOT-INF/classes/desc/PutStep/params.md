*Optional.* A map of arbitrary configuration to forward to the resource. 

Refer to the resource type's documentation to see what it supports.