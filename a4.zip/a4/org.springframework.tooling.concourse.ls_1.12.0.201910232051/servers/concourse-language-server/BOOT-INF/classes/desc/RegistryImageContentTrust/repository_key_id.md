*Required.* Target key's ID used to sign the trusted collection, could be retrieved by `notary key list`
