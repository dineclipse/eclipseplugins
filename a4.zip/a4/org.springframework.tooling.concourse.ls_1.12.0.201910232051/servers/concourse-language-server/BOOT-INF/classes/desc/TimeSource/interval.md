*Optional.* The interval on which to report new versions. Valid
values: `60s`, `90m`, `1h`.