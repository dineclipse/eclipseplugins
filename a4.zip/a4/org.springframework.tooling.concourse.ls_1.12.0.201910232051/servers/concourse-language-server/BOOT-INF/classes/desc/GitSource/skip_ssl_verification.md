*Optional.* Skips git ssl verification by exporting
`GIT_SSL_NO_VERIFY=true`.