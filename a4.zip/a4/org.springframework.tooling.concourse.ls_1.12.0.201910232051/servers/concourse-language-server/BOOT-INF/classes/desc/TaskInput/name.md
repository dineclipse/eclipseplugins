*Required.* The logical name of the input.
