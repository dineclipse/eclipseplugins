*Optional.* Indicates that the bucket is private, so that any
URLs provided are signed.
