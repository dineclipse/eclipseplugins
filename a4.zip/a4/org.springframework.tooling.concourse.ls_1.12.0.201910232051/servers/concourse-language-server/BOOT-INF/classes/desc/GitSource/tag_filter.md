`tag_filter`: *Optional.* If specified, the resource will only detect commits
that have a tag matching the specified expression. Patterns are
[glob(7)](https://man7.org/linux/man-pages/man7/glob.7.html) compatible (as
in, bash compatible).