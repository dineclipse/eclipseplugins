*Optional*. Path to a JSON file containing the image labels.

Example file contents:

```
{ "commit": "b4d4823", "version": "1.0.3" }
```
