*Optional. Default `rootfs`.* The format to fetch as.
