*Optional.* A URL pointing to a docker registry mirror service.
