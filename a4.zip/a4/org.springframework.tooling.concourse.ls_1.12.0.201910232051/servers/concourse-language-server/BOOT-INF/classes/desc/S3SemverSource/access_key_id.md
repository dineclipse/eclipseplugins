*Required.* The AWS access key to use when accessing the
bucket.