*Optional*. A map of labels that will be added to the image.

Example:

```
labels:
  commit: b4d4823
  version: 1.0.3
```
