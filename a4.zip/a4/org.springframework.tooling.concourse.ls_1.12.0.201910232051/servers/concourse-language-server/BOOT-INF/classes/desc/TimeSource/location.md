*Optional. Default `UTC`.* The
[location](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones) in
which to interpret `start`, `stop`, and `days`.

e.g.

	location: Africa/Abidjan
