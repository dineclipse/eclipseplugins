*Optional*. List of variables files to pass to manifest.
