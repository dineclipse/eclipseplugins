*Optional*. Default `latest`. The name of the tag to monitor and publish to.
