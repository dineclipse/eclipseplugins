If true, we will attempt to move a randomly chosen lock from the
pool's unclaimed directory to the claimed directory. Acquiring will retry
until a lock becomes available.