*Optional.*  [Canned Acl](https://docs.aws.amazon.com/AmazonS3/latest/dev/acl-overview.html)
for the uploaded object.