*Optional.* The path of a directory containing an image that was
fetched using this same resource with `save: true`.