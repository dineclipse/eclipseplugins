*Optional.* If `none`, submodules will not be fetched. If specified as 
a list of paths, only the given paths will be fetched. If not specified, 
or if `all` is explicitly specified, all submodules are fetched.