*Optional*. Tails the app log during startup, useful to debug issues when using blue/green deploys together with the `current_app_name` option.

