*Optional.* AWS access key to use for acquiring ECR
credentials.