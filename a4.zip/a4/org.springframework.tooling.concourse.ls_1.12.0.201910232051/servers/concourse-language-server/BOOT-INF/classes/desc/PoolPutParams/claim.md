If set, the specified lock from the pool will be acquired, rather
than a random one (as in `acquire`). Like `acquire`, claiming will retry
until the specific lock becomes available