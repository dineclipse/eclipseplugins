*Required.* The name of the resource. This should be short and simple. This name will be referenced by [build plans](https://concourse-ci.org/build-plans.html) of jobs in the pipeline.
