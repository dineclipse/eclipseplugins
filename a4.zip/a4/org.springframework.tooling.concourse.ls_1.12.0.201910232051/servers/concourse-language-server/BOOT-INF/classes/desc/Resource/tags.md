*Optional*. A list of tags to determine which workers the checks will be performed on. You'll want to specify this if 
the source is internal to a worker's network, for example. See also [tags](https://concourse-ci.org/tags-step-modifier.html) step modifier.

