*Optional*. This should be the users password when authenticating against a protected docker registry.

