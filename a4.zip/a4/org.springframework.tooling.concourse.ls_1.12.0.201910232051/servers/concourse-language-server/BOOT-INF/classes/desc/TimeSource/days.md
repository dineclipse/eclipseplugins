*Optional.* Run only on these day(s). Supported days are: `Sunday`,
`Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday` and `Saturday`.

e.g.

	days: [Monday, Wednesday]
