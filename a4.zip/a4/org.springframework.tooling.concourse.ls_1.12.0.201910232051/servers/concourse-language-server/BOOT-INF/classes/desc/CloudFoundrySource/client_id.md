*Optional*. The client id used to authenticate.
