*Optional.* The path to a file with whitespace-separated 
list of tag values to tag the image with (in addition to the tag configured in 
`source`).
