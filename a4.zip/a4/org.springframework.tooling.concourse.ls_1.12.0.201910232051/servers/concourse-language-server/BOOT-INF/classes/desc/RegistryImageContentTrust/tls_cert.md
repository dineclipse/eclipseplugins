*Optional. Default `""`* TLS certificate for the notary server.
