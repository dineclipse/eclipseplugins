*Optional. Default `false`.* If set, progress bars will be disabled
  and debugging output will be printed instead.
