*Optional*. Deploys the app but does not start it. This parameter is ignored when `current_app_name` is specified.
