If set, we will add a new lock to the pool in the unclaimed state. The
value is the path to a directory containing the files `name` and `metadata`
which should contain the name of your new lock and the contents you would like
in the lock, respectively.