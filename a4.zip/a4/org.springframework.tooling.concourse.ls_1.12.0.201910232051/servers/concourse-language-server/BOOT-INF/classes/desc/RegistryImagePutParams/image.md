*Required.* The path to the OCI image tarball to upload.
