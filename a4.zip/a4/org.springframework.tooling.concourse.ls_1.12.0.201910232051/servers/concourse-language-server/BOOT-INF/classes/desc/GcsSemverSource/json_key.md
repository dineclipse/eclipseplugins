*Required*. The contents of your GCP Account JSON Key. Example:

	json_key: |
	  {
	    "private_key_id": "...",
	    "private_key": "...",
	    "client_email": "...",
	    "client_id": "...",
	    "type": "service_account"
	  }