*Optional.* The path of the `Dockerfile` in the directory if
it's not at the root of the directory.