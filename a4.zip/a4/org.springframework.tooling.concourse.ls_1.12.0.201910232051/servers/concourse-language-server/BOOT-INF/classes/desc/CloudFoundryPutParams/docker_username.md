*Optional*. This is used as the username to authenticate against a protected docker registry.
