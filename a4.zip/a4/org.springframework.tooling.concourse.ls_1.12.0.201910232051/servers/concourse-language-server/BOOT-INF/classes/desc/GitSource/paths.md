*Optional.* If specified (as a list of glob patterns), only changes
to the specified files will yield new versions from `check`.