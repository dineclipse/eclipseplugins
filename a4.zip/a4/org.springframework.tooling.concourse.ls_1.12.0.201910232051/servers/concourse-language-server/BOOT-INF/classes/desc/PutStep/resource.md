*Optional.* Defaults to `name`.

The resource to update, as configured in [resources](https://concourse-ci.org/configuring-resources.html).
