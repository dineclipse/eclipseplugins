*Optional*. Skip SSL verification for S3 endpoint. Useful for S3 compatible providers using self-signed SSL certificates.
