*Required*. The address of the Cloud Controller in the Cloud Foundry deployment.
username