*Optional*. Maximum concurrent uploads.

Limits the number of concurrent upload threads.