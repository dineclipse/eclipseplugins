*Optional.*  **DEPRECATED. Use `get` and `load` instead.** Default
`latest`. The tag of the repository to pull down via `pull_repository`.