*Optional.* The git identity to use when pushing to the
repository support RFC 5322 address of the form "Gogh Fir \<gf@example.com\>" or "foo@example.com".