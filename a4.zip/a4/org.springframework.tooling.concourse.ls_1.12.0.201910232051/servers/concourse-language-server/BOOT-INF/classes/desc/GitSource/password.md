*Optional.* Password for HTTP(S) auth when pulling/pushing.

Note: You can also use pipeline templating to hide this password in source control. (For more information: https://concourse-ci.org/fly-set-pipeline.html)
