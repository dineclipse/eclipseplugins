*Optional.* AWS secret key to use for acquiring ECR
credentials.