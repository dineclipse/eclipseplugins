*Optional.* Skip `docker pull` of image. Artifacts based
on the image will not be present.