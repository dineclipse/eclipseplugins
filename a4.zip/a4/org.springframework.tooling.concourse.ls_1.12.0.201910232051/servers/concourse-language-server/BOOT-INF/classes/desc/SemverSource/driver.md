*Optional. Default `s3`.* The driver to use for tracking the
version. Determines where the version is stored.